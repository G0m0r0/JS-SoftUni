export * from './about.js';
export * from './auth.js';
export * from './details.js';
export * from './common.js';
export * from './home.js';
export * from './team.js';
export * from './likes.js';
export * from './delete.js';