## In Order to run this project

1.  Use any sort of live-server
2.  Provide firebase database url in each `app.js` file
3.  Set the firebase rules for read/write to true
4.  Keep in mind that there is no solution for the third task

PR-s and questions will be appreciated :D
