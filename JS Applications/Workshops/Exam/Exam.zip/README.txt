change name attribute of repeat password in register form(from rep-pass to reppass);
dashboard is sorted
