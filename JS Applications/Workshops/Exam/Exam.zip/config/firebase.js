const firebaseConfig = {
    apiKey: "AIzaSyB901xLrp3KZf-X8TiO3zbSwijwrAe3p3E",
    authDomain: "examnpm.firebaseapp.com",
    databaseURL: "https://examnpm.firebaseio.com",
    projectId: "examnpm",
    storageBucket: "examnpm.appspot.com",
    messagingSenderId: "670437044985",
    appId: "1:670437044985:web:701be1376c36a7307ee828",
    measurementId: "G-ZWFX3YQT3D"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
  //firebase.analytics();