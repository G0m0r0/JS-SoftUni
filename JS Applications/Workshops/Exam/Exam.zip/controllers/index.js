import user from './user.js';
import article from './article.js';
import home from './home.js';

export default{
    user,
    article,
    home
};