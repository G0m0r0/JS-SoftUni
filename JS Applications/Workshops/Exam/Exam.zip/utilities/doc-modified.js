export default function(d){
    return {...d.data(),id: d.id}
}